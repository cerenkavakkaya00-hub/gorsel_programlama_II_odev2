﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace ödev2
{
    // --- 1. VERİ MODELLERİ (Sistem Yapı Taşları) ---
    public class Bagisci
    {
        public string ID { get; set; }
        public string AdSoyad { get; set; }
        public string Tur { get; set; }         // "Kan" veya "Organ"
        public string Detay { get; set; }       // "A Rh+", "Böbrek", "Karaciğer" vb.
        public string HLATipi { get; set; }     // Doku Uyum Kodu
        public DateTime KayitTarihi { get; set; }
    }

    public class Alici
    {
        public string ID { get; set; }
        public string AdSoyad { get; set; }
        public string Tur { get; set; }         // "Kan" veya "Organ"
        public string Detay { get; set; }
        public string HLATipi { get; set; }
        public int AciliyetSkoru { get; set; }  // 1 - 10 Arası Kritiklik Derecesi
    }

    // --- 2. ANA FORMA ENTEGRE EDİLMİŞ GELİŞMİŞ SİSTEM ---
    public partial class Form1 : Form
    {
        // Bellek İçi Veri Depoları (In-Memory DB)
        private List<Bagisci> bagisciListesi = new List<Bagisci>();
        private List<Alici> aliciListesi = new List<Alici>();

        // Kod ile Oluşturulacak Arayüz Kontrolleri
        private TabControl anaTabControl;
        private TabPage tabBagisci, tabAlici, tabEslesme;

        // Bağışçı Paneli Kontrolleri
        private TextBox txtBagisciAd, txtBagisciDetay, txtBagisciHLA;
        private ComboBox cmbBagisciTur;
        private DataGridView dgvBagiscilar;

        // Alıcı Paneli Kontrolleri
        private TextBox txtAliciAd, txtAliciDetay, txtAliciHLA;
        private ComboBox cmbAliciTur, cmbAciliyet;
        private DataGridView dgvAlicilar;

        // Eşleşme Motoru Kontrolleri
        private ListView lvEslesmeler;
        private Label lblIstatistik;

        public Form1()
        {
            // Visual Studio'nun varsayılan bileşen başlatıcısı
            InitializeComponent();

            // Formun Genel Görsel ve Yapısal Ayarları
            this.Text = "Bilişim Teknolojileri - Kan ve Organ Nakli Süreç Yönetimi";
            this.Size = new Size(1150, 720);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(245, 246, 250); // Gözü yormayan modern gri arka plan
            this.Font = new Font("Segoe UI", 10, FontStyle.Regular);

            // Simüle edilmiş hazır verileri sisteme yükle
            MockVeriYukle();

            // Tüm arayüzü kodla çizen ana fonksiyon
            DinamikArayuzInsaEt();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // İhtiyaca göre yükleme anında çalışacak kodlar buraya eklenebilir.
            VerileriListele();
        }

        private void DinamikArayuzInsaEt()
        {
            // --- ÜST BAŞLIK PANELDİR (HEADER) ---
            Panel pnlHeader = new Panel
            {
                Dock = DockStyle.Top,
                Height = 75,
                BackColor = Color.FromArgb(192, 57, 43) // Sağlık ve aciliyet temalı derin kırmızı
            };
            Label lblTitle = new Label
            {
                Text = "KAN VE ORGAN NAKLİ SÜREÇLERİ OTOMASYONU",
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 16, FontStyle.Bold),
                Location = new Point(25, 22),
                AutoSize = true
            };
            pnlHeader.Controls.Add(lblTitle);
            this.Controls.Add(pnlHeader);

            // --- TAB KONTROLÜ YAPISI ---
            anaTabControl = new TabControl { Dock = DockStyle.Fill, Font = new Font("Segoe UI", 11, FontStyle.Bold) };
            tabBagisci = new TabPage { Text = "  Bağışçı / Donör Kayıt  ", BackColor = Color.White };
            tabAlici = new TabPage { Text = "  Hasta / Bekleme Listesi  ", BackColor = Color.White };
            tabEslesme = new TabPage { Text = "  Bilişimsel Eşleştirme Motoru  ", BackColor = Color.White };

            anaTabControl.TabPages.AddRange(new TabPage[] { tabBagisci, tabAlici, tabEslesme });
            this.Controls.Add(anaTabControl);
            anaTabControl.BringToFront(); // Header panelinin altında kalmasını önler

            // --- SEKMELERİN DETAYLI TASARIMLARI ---
            BagisciSekmesiTasarla();
            AliciSekmesiTasarla();
            EslesmeSekmesiTasarla();
        }

        #region BAĞIŞÇI MODÜLÜ
        private void BagisciSekmesiTasarla()
        {
            // Giriş Paneli (Sol Taraf)
            Panel pnlInput = new Panel { Dock = DockStyle.Left, Width = 360, Padding = new Padding(20), BackColor = Color.FromArgb(240, 240, 240) };

            Label lblAd = new Label { Text = "Bağışçı Adı Soyadı:", Top = 20, Left = 20, AutoSize = true };
            txtBagisciAd = new TextBox { Top = 45, Left = 20, Width = 310 };

            Label lblTur = new Label { Text = "Bağış Türü:", Top = 95, Left = 20, AutoSize = true };
            cmbBagisciTur = new ComboBox { Top = 120, Left = 20, Width = 310, DropDownStyle = ComboBoxStyle.DropDownList };
            cmbBagisciTur.Items.AddRange(new string[] { "Kan", "Organ" });

            Label lblDetay = new Label { Text = "Detay (Örn: 0 Rh+ veya Böbrek):", Top = 170, Left = 20, AutoSize = true };
            txtBagisciDetay = new TextBox { Top = 195, Left = 20, Width = 310 };

            Label lblHLA = new Label { Text = "Doku Uyumu (HLA Dokusu):", Top = 245, Left = 20, AutoSize = true };
            txtBagisciHLA = new TextBox { Top = 270, Left = 20, Width = 310 };

            Button btnEkle = new Button
            {
                Text = "SİSTEME BAĞIŞÇI EKLE",
                Top = 330,
                Left = 20,
                Width = 310,
                Height = 48,
                BackColor = Color.FromArgb(46, 204, 113),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnEkle.Font = new Font("Segoe UI", 11, FontStyle.Bold);
            btnEkle.Click += BtnBagisciEkle_Click;

            pnlInput.Controls.AddRange(new Control[] { lblAd, txtBagisciAd, lblTur, cmbBagisciTur, lblDetay, txtBagisciDetay, lblHLA, txtBagisciHLA, btnEkle });

            // İzleme Izgarası (Sağ Taraf)
            dgvBagiscilar = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                RowHeadersVisible = false
            };
            dgvBagiscilar.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 249, 250);

            tabBagisci.Controls.Add(dgvBagiscilar);
            tabBagisci.Controls.Add(pnlInput);
        }

        private void BtnBagisciEkle_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtBagisciAd.Text) || cmbBagisciTur.SelectedIndex == -1)
            {
                MessageBox.Show("Eksik alan bıraktınız. Lütfen isim ve tür seçiniz.", "Sistem Uyarısı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            bagisciListesi.Add(new Bagisci
            {
                ID = "DONOR-" + (bagisciListesi.Count + 1001),
                AdSoyad = txtBagisciAd.Text,
                Tur = cmbBagisciTur.SelectedItem.ToString(),
                Detay = txtBagisciDetay.Text.ToUpper(),
                HLATipi = txtBagisciHLA.Text.ToUpper(),
                KayitTarihi = DateTime.Now
            });

            VerileriListele();
            txtBagisciAd.Clear(); txtBagisciDetay.Clear(); txtBagisciHLA.Clear(); cmbBagisciTur.SelectedIndex = -1;
            MessageBox.Show("Donör kaydı veri tabanına başarıyla işlendi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        #endregion

        #region ALICI (HASTA) MODÜLÜ
        private void AliciSekmesiTasarla()
        {
            // Giriş Paneli (Sol Taraf)
            Panel pnlInput = new Panel { Dock = DockStyle.Left, Width = 360, Padding = new Padding(20), BackColor = Color.FromArgb(240, 240, 240) };

            Label lblAd = new Label { Text = "Hasta Adı Soyadı:", Top = 20, Left = 20, AutoSize = true };
            txtAliciAd = new TextBox { Top = 45, Left = 20, Width = 310 };

            Label lblTur = new Label { Text = "Gereksinim Türü:", Top = 95, Left = 20, AutoSize = true };
            cmbAliciTur = new ComboBox { Top = 120, Left = 20, Width = 310, DropDownStyle = ComboBoxStyle.DropDownList };
            cmbAliciTur.Items.AddRange(new string[] { "Kan", "Organ" });

            Label lblDetay = new Label { Text = "Detay (Örn: 0 Rh+ veya Böbrek):", Top = 170, Left = 20, AutoSize = true };
            txtAliciDetay = new TextBox { Top = 195, Left = 20, Width = 310 };

            Label lblHLA = new Label { Text = "Doku Uyumu (HLA Dokusu):", Top = 245, Left = 20, AutoSize = true };
            txtAliciHLA = new TextBox { Top = 270, Left = 20, Width = 310 };

            Label lblAcil = new Label { Text = "Kritiklik / Aciliyet Seviyesi (1-10):", Top = 320, Left = 20, AutoSize = true };
            cmbAciliyet = new ComboBox { Top = 345, Left = 20, Width = 310, DropDownStyle = ComboBoxStyle.DropDownList };
            for (int i = 1; i <= 10; i++) cmbAciliyet.Items.Add(i);

            Button btnEkle = new Button
            {
                Text = "HASTAYI BEKLEME LİSTESİNE AL",
                Top = 405,
                Left = 20,
                Width = 310,
                Height = 48,
                BackColor = Color.FromArgb(41, 128, 185),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnEkle.Font = new Font("Segoe UI", 11, FontStyle.Bold);
            btnEkle.Click += BtnAliciEkle_Click;

            pnlInput.Controls.AddRange(new Control[] { lblAd, txtAliciAd, lblTur, cmbAliciTur, lblDetay, txtAliciDetay, lblHLA, txtAliciHLA, lblAcil, cmbAciliyet, btnEkle });

            // İzleme Izgarası (Sağ Taraf)
            dgvAlicilar = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                RowHeadersVisible = false
            };
            dgvAlicilar.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 249, 250);

            tabAlici.Controls.Add(dgvAlicilar);
            tabAlici.Controls.Add(pnlInput);
        }

        private void BtnAliciEkle_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtAliciAd.Text) || cmbAliciTur.SelectedIndex == -1 || cmbAciliyet.SelectedIndex == -1)
            {
                MessageBox.Show("Lütfen tüm alanları doldurarak aciliyet puanı ataması yapın.", "Sistem Uyarısı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            aliciListesi.Add(new Alici
            {
                ID = "HASTA-" + (aliciListesi.Count + 5001),
                AdSoyad = txtAliciAd.Text,
                Tur = cmbAliciTur.SelectedItem.ToString(),
                Detay = txtAliciDetay.Text.ToUpper(),
                HLATipi = txtAliciHLA.Text.ToUpper(),
                AciliyetSkoru = Convert.ToInt32(cmbAciliyet.SelectedItem)
            });

            VerileriListele();
            txtAliciAd.Clear(); txtAliciDetay.Clear(); txtAliciHLA.Clear(); cmbAliciTur.SelectedIndex = -1; cmbAciliyet.SelectedIndex = -1;
            MessageBox.Show("Hasta, ulusal bekleme sırasına başarıyla dahil edildi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        #endregion

        #region BİLİŞİMSEL EŞLEŞTİRME ALGORİTMASI (Cross-Matching)
        private void EslesmeSekmesiTasarla()
        {
            // Üst Algoritma Tetikleme Paneli
            Panel pnlTop = new Panel { Dock = DockStyle.Top, Height = 85, BackColor = Color.FromArgb(52, 73, 94), Padding = new Padding(15) };

            Button btnEslestir = new Button
            {
                Text = "CROSS-MATCH ALGORTİMASINI ÇALIŞTIR",
                Left = 20,
                Top = 18,
                Width = 360,
                Height = 50,
                BackColor = Color.FromArgb(230, 126, 34),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnEslestir.Font = new Font("Segoe UI", 12, FontStyle.Bold);
            btnEslestir.Click += BtnEslestir_Click;

            lblIstatistik = new Label
            {
                Text = "Bilişimsel analiz başlatılmaya hazır. Lütfen butona tıklayın.",
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 11, FontStyle.Italic),
                Left = 400,
                Top = 32,
                AutoSize = true
            };
            pnlTop.Controls.AddRange(new Control[] { btnEslestir, lblIstatistik });

            // Sonuçları Listeleyen Gelişmiş Liste Görünümü
            lvEslesmeler = new ListView
            {
                Dock = DockStyle.Fill,
                View = View.Details,
                FullRowSelect = true,
                GridLines = true,
                Font = new Font("Segoe UI", 10, FontStyle.Regular)
            };
            lvEslesmeler.Columns.Add("Uyum Yüzdesi", 140);
            lvEslesmeler.Columns.Add("Kaynak Donör", 240);
            lvEslesmeler.Columns.Add("Hedef Hasta", 240);
            lvEslesmeler.Columns.Add("Doku/Organ Türü", 160);
            lvEslesmeler.Columns.Add("HLA Uyumu", 150);
            lvEslesmeler.Columns.Add("Tıbbi Durum", 160);

            tabEslesme.Controls.Add(lvEslesmeler);
            tabEslesme.Controls.Add(pnlTop);
        }

        private void BtnEslestir_Click(object sender, EventArgs e)
        {
            lvEslesmeler.Items.Clear();
            int acilVakaSayisi = 0;

            // Çapraz Eşleştirme Yapay Karar Matrisi
            foreach (var donor in bagisciListesi)
            {
                foreach (var hasta in aliciListesi)
                {
                    // Temel Şart: Tür ve Tıbbi Detay uyuşmalıdır.
                    if (donor.Tur == hasta.Tur && donor.Detay == hasta.Detay)
                    {
                        double toplamUyumSkoru = 50.0; // Temel biyolojik uyum taban puanı
                        bool hlaKritikUyum = false;

                        // HLA Genetik Doku Testi Analizi
                        if (!string.IsNullOrEmpty(donor.HLATipi) && donor.HLATipi == hasta.HLATipi)
                        {
                            toplamUyumSkoru += 30.0; // Tam doku uyuşması ödülü
                            hlaKritikUyum = true;
                        }

                        // Hastanın Hayati Risk Faktörünün Hesaba Katılması (+20 Puana kadar)
                        toplamUyumSkoru += (hasta.AciliyetSkoru * 2);

                        // %60 ve üzeri tıbbi başarı oranına sahip olasılıkları listele
                        if (toplamUyumSkoru >= 60)
                        {
                            ListViewItem satir = new ListViewItem($"%{toplamUyumSkoru} Başarı");

                            // Durumu kritik olan hastalarda satır rengini kırmızı tonlarına çeker (Görsel Önceliklendirme)
                            if (hasta.AciliyetSkoru >= 8)
                            {
                                satir.BackColor = Color.FromArgb(255, 230, 230);
                                satir.ForeColor = Color.DarkRed;
                                acilVakaSayisi++;
                            }
                            else
                            {
                                satir.BackColor = Color.FromArgb(230, 255, 230); // Optimum uyumlu stabil hastalar
                                satir.ForeColor = Color.DarkGreen;
                            }

                            satir.SubItems.Add($"{donor.AdSoyad} ({donor.ID})");
                            satir.SubItems.Add($"{hasta.AdSoyad} ({hasta.ID})");
                            satir.SubItems.Add($"{donor.Tur} [{donor.Detay}]");
                            satir.SubItems.Add(hlaKritikUyum ? "TAM GENETİK UYUM" : "Kısmi Biyolojik Uyum");
                            satir.SubItems.Add($"Kritiklik: {hasta.AciliyetSkoru}/10 ({(hasta.AciliyetSkoru >= 8 ? "ACİL NAKİL" : "Stabil")})");

                            lvEslesmeler.Items.Add(satir);
                        }
                    }
                }
            }

            lblIstatistik.Text = $"Eşleştirme Tamamlandı. Toplam {lvEslesmeler.Items.Count} adet uygun varyasyon listelendi. {acilVakaSayisi} vaka kırmızı kodlu.";
        }
        #endregion

        #region YARDIMCI VE SİMÜLASYON METOTLARI
        private void VerileriListele()
        {
            dgvBagiscilar.DataSource = null;
            dgvBagiscilar.DataSource = bagisciListesi;

            dgvAlicilar.DataSource = null;
            dgvAlicilar.DataSource = aliciListesi;
        }

        private void MockVeriYukle()
        {
            // Program ilk açıldığında boş ekran gelmemesi için veritabanı simülasyon kayıtları
            bagisciListesi.Add(new Bagisci { ID = "DONOR-101", AdSoyad = "Ahmet Yılmaz", Tur = "Kan", Detay = "0 RH+", HLATipi = "HLA-A12", KayitTarihi = DateTime.Now.AddDays(-5) });
            bagisciListesi.Add(new Bagisci { ID = "DONOR-102", AdSoyad = "Mehmet Demir", Tur = "Organ", Detay = "BÖBREK", HLATipi = "HLA-B44", KayitTarihi = DateTime.Now.AddDays(-2) });
            bagisciListesi.Add(new Bagisci { ID = "DONOR-103", AdSoyad = "Arzu Kaya", Tur = "Organ", Detay = "KARACİĞER", HLATipi = "HLA-C02", KayitTarihi = DateTime.Now });

            aliciListesi.Add(new Alici { ID = "HASTA-501", AdSoyad = "Selin Öztürk", Tur = "Kan", Detay = "0 RH+", HLATipi = "HLA-A12", AciliyetSkoru = 6 });
            aliciListesi.Add(new Alici { ID = "HASTA-502", AdSoyad = "Mustafa Yıldız", Tur = "Organ", Detay = "BÖBREK", HLATipi = "HLA-B44", AciliyetSkoru = 10 }); // Tam uyum ve acil vaka
            aliciListesi.Add(new Alici { ID = "HASTA-503", AdSoyad = "Hasan Şahin", Tur = "Organ", Detay = "BÖBREK", HLATipi = "HLA-Z99", AciliyetSkoru = 4 });     // Doku uyumsuz vaka
        }
        #endregion
    }
}